package poly.edu;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Lab4Ts01101Java51ApplicationTests {

	@Test
	void contextLoads() {
	}

}
