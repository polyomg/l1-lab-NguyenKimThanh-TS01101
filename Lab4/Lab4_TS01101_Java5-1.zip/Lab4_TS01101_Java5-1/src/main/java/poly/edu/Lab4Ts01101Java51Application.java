package poly.edu;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Lab4Ts01101Java51Application {

	public static void main(String[] args) {
		SpringApplication.run(Lab4Ts01101Java51Application.class, args);
	}

}
