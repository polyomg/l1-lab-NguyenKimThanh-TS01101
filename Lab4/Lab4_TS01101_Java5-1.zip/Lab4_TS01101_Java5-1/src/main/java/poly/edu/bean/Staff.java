package poly.edu.bean;

import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Email;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Staff {
    @NotEmpty(message = "Không được bỏ trống tên")
    private String fullname;

    @NotNull(message = "Vui lòng nhập lương")
    private Double salary;

    @Email(message = "Email không hợp lệ")
    private String email;

    private Boolean gender;
    private String country;
}
