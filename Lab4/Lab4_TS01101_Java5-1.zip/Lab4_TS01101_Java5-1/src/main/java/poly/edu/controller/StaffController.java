package poly.edu.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import jakarta.validation.Valid;
import poly.edu.bean.Staff;

@Controller
public class StaffController {

    @GetMapping("/staff/create")
    public String create(Model model) {
        model.addAttribute("staff", new Staff());
        return "staff/create";
    }

    @PostMapping("/staff/save")
    public String save(@Valid Staff staff, BindingResult result, Model model) {
        if (result.hasErrors()) {
            return "staff/create";
        }
        model.addAttribute("staff", staff);
        return "staff/validate";
    }
}
