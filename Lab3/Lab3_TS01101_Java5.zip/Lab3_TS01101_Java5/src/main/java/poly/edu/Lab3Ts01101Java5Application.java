package poly.edu;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Lab3Ts01101Java5Application {

	public static void main(String[] args) {
		SpringApplication.run(Lab3Ts01101Java5Application.class, args);
	}

}
