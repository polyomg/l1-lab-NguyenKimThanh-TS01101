package poly.edu;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Lab3Ts01101Java5ApplicationTests {

	@Test
	void contextLoads() {
	}

}
