package poly.edu;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Lab1Ts01101Java5ApplicationTests {

	@Test
	void contextLoads() {
	}

}
