package poly.edu.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Product {
    String name;
    Double price;
	public Product() {
		// TODO Auto-generated constructor stub
	}
	public Product(String string, double d) {
		// TODO Auto-generated constructor stub
	}
	public Object getName() {
		// TODO Auto-generated method stub
		return null;
	}
	public void setName(String string) {
		// TODO Auto-generated method stub
		
	}
	public void setPrice(double d) {
		// TODO Auto-generated method stub
		
	}
}
